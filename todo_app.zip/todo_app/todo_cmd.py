#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Personal To-Do List Application (CLI)
- Add, view, edit, complete, delete tasks
- Categorize tasks (Work, Personal, Urgent, or custom)
- Persistent JSON storage (tasks.json)
- No external DBs required
"""

import json
import os
from dataclasses import dataclass, asdict
from typing import List, Optional

DATA_FILE = os.path.join(os.path.dirname(__file__), "tasks.json")
VALID_CATEGORIES = ["Work", "Personal", "Urgent"]

@dataclass
class Task:
    title: str
    description: str
    category: str
    completed: bool = False

    def mark_completed(self) -> None:
        self.completed = True

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Task":
        # Handle missing keys gracefully
        return Task(
            title=d.get("title", ""),
            description=d.get("description", ""),
            category=d.get("category", "Personal"),
            completed=bool(d.get("completed", False)),
        )

def save_tasks(tasks: List[Task], filename: str = DATA_FILE) -> None:
    with open(filename, "w", encoding="utf-8") as f:
        json.dump([t.to_dict() for t in tasks], f, indent=2, ensure_ascii=False)

def load_tasks(filename: str = DATA_FILE) -> List[Task]:
    if not os.path.exists(filename):
        return []
    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
            return [Task.from_dict(d) for d in data]
    except (json.JSONDecodeError, OSError):
        print("Warning: tasks.json is corrupted or unreadable. Starting with an empty list.")
        return []

# ---------- UI Helpers ----------

def print_header(title: str) -> None:
    print("\n" + "-" * 40)
    print(title)
    print("-" * 40)

def pause() -> None:
    input("Press Enter to continue...")

def confirm(prompt: str) -> bool:
    return input(f"{prompt} (y/N): ").strip().lower() == "y"

def choose_index(max_index: int, prompt: str = "Enter number") -> Optional[int]:
    try:
        idx = int(input(f"{prompt}: ").strip()) - 1
        if 0 <= idx < max_index:
            return idx
        print("Out of range.")
        return None
    except ValueError:
        print("Please enter a valid number.")
        return None

def input_nonempty(prompt: str) -> str:
    while True:
        val = input(prompt).strip()
        if val:
            return val
        print("This field cannot be empty.")

def input_category() -> str:
    print(f"Choose a category or type your own: {', '.join(VALID_CATEGORIES)}")
    cat = input("Category: ").strip()
    return cat if cat else "Personal"

# ---------- Core Actions ----------

def add_task(tasks: List[Task]) -> None:
    print_header("Add Task")
    title = input_nonempty("Title: ")
    description = input("Description: ").strip()
    category = input_category()
    tasks.append(Task(title, description, category))
    print("✅ Task added.")

def list_tasks(tasks: List[Task], show_all: bool = True, category_filter: Optional[str] = None) -> None:
    print_header("Your Tasks")
    if not tasks:
        print("No tasks yet.")
        return
    for i, t in enumerate(tasks, start=1):
        if category_filter and t.category.lower() != category_filter.lower():
            continue
        if not show_all and t.completed:
            continue
        status = "✅ Completed" if t.completed else "⌛ Pending"
        print(f"{i}. {t.title} [{t.category}] - {status}")
        if t.description:
            print(f"   {t.description}")
    print()

def mark_task_completed(tasks: List[Task]) -> None:
    print_header("Mark Task Completed")
    if not tasks:
        print("No tasks to update."); return
    list_tasks(tasks)
    idx = choose_index(len(tasks), "Select task number to mark completed")
    if idx is None: return
    tasks[idx].mark_completed()
    print(f"✅ Marked '{tasks[idx].title}' as completed.")

def delete_task(tasks: List[Task]) -> None:
    print_header("Delete Task")
    if not tasks:
        print("No tasks to delete."); return
    list_tasks(tasks)
    idx = choose_index(len(tasks), "Select task number to delete")
    if idx is None: return
    t = tasks[idx]
    if confirm(f"Are you sure you want to delete '{t.title}'?"):
        tasks.pop(idx)
        print("🗑️ Task deleted.")
    else:
        print("Deletion cancelled.")

def edit_task(tasks: List[Task]) -> None:
    print_header("Edit Task")
    if not tasks:
        print("No tasks to edit."); return
    list_tasks(tasks)
    idx = choose_index(len(tasks), "Select task number to edit")
    if idx is None: return
    task = tasks[idx]
    print(f"Editing '{task.title}' (leave blank to keep current)")
    new_title = input(f"New title [{task.title}]: ").strip()
    new_desc = input(f"New description [{task.description}]: ").strip()
    new_cat = input(f"New category [{task.category}]: ").strip()

    if new_title: task.title = new_title
    if new_desc: task.description = new_desc
    if new_cat: task.category = new_cat

    print("✏️ Task updated.")

def filter_menu(tasks: List[Task]) -> None:
    print_header("View Options")
    print("1. View All")
    print("2. View Only Pending")
    print("3. View by Category")
    choice = input("Choose an option: ").strip()
    if choice == "1":
        list_tasks(tasks, show_all=True)
    elif choice == "2":
        list_tasks(tasks, show_all=False)
    elif choice == "3":
        cat = input_nonempty("Enter category to filter: ")
        list_tasks(tasks, show_all=True, category_filter=cat)
    else:
        print("Invalid choice.")

# ---------- Main Loop ----------

def main() -> None:
    tasks = load_tasks()
    while True:
        print_header("Personal To-Do List")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Mark Task Completed")
        print("4. Edit Task")
        print("5. Delete Task")
        print("6. Save & Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            add_task(tasks)
        elif choice == "2":
            filter_menu(tasks)
        elif choice == "3":
            mark_task_completed(tasks)
        elif choice == "4":
            edit_task(tasks)
        elif choice == "5":
            delete_task(tasks)
        elif choice == "6":
            save_tasks(tasks)
            print("💾 Tasks saved. Goodbye!")
            break
        else:
            print("Invalid option. Try again.")

        # Auto-save after each action to be safe
        save_tasks(tasks)
        pause()

if __name__ == "__main__":
    main()
