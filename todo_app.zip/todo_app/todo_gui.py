import tkinter as tk
from tkinter import messagebox, ttk
import json
import sys
import os

# Detect base directory whether running as script or exe
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)   # when running as exe
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # when running as script

DATA_FILE = os.path.join(BASE_DIR, "tasks.json")


class SplashScreen(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.overrideredirect(True)   # removes title bar
        self.geometry("400x200")
        self.configure(bg="white")

        # Center splash on screen
        self.update_idletasks()
        w = 400
        h = 200
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

        tk.Label(self, text="Welcome to To-Do App", font=("Arial", 16), bg="white").pack(expand=True)
        ttk.Progressbar(self, mode="indeterminate").pack(fill="x", padx=20, pady=20)

class Task:
    def __init__(self, title, description, category, completed=False):
        self.title = title
        self.description = description
        self.category = category
        self.completed = completed

    def to_dict(self):
        return self.__dict__

    @staticmethod
    def from_dict(d):
        return Task(**d)

def save_tasks(tasks):
    with open(DATA_FILE, "w") as f:
        json.dump([t.to_dict() for t in tasks], f, indent=4)

def load_tasks():
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r") as f:
            return [Task.from_dict(d) for d in json.load(f)]
    except:
        return []

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Personal To-Do List")
        self.center_window(self.root, 600, 400)

        self.tasks = load_tasks()

        # Frame
        frame = tk.Frame(root)
        frame.pack(padx=10, pady=10)

        # Task list
        self.task_list = tk.Listbox(frame, width=60, height=12)
        self.task_list.pack(side=tk.LEFT, fill=tk.BOTH)
        self.task_list.bind("<Double-1>", self.show_description)

        # Scrollbar
        scrollbar = tk.Scrollbar(frame, orient="vertical")
        scrollbar.config(command=self.task_list.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.task_list.config(yscrollcommand=scrollbar.set)

        # Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="Add Task", command=self.add_task).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Mark Completed", command=self.mark_completed).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Delete Task", command=self.delete_task).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="Save & Exit", command=self.save_and_exit).grid(row=0, column=3, padx=5)

        self.refresh_tasks()

    def center_window(self, win, width=600, height=400):
        screen_width = win.winfo_screenwidth()
        screen_height = win.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        win.geometry(f"{width}x{height}+{x}+{y}")

    def refresh_tasks(self):
        self.task_list.delete(0, tk.END)
        for idx, t in enumerate(self.tasks):
            status = "✅" if t.completed else "❌"
            self.task_list.insert(tk.END, f"{idx+1}. {t.title} [{t.category}] {status}")

    def add_task(self):
        add_window = tk.Toplevel(self.root)
        add_window.title("Add Task")
        self.center_window(add_window, 500, 350)  # bigger window, centered

        tk.Label(add_window, text="Task Title:").pack(pady=5)
        title_entry = tk.Entry(add_window, width=40)
        title_entry.pack(pady=5)

        tk.Label(add_window, text="Task Description:").pack(pady=5)
        desc_entry = tk.Entry(add_window, width=40)
        desc_entry.pack(pady=5)

        tk.Label(add_window, text="Choose Category:").pack(pady=10)

        selected_category = tk.StringVar(value="Personal")

        def set_category(cat):
            selected_category.set(cat)

        cat_frame = tk.Frame(add_window)
        cat_frame.pack(pady=5)

        tk.Button(cat_frame, text="Work", width=10, command=lambda: set_category("Work")).grid(row=0, column=0, padx=5)
        tk.Button(cat_frame, text="Personal", width=10, command=lambda: set_category("Personal")).grid(row=0, column=1, padx=5)
        tk.Button(cat_frame, text="Urgent", width=10, command=lambda: set_category("Urgent")).grid(row=0, column=2, padx=5)

        def save_new_task():
            title = title_entry.get()
            desc = desc_entry.get()
            category = selected_category.get()
            if not title:
                messagebox.showwarning("Warning", "Task title cannot be empty!")
                return
            self.tasks.append(Task(title, desc, category))
            self.refresh_tasks()
            add_window.destroy()

        tk.Button(add_window, text="Add Task", command=save_new_task).pack(pady=20)

    def mark_completed(self):
        try:
            idx = self.task_list.curselection()[0]
            self.tasks[idx].completed = True
            self.refresh_tasks()
        except IndexError:
            messagebox.showwarning("Warning", "Select a task first!")

    def delete_task(self):
        try:
            idx = self.task_list.curselection()[0]
            del self.tasks[idx]
            self.refresh_tasks()
        except IndexError:
            messagebox.showwarning("Warning", "Select a task first!")

    def show_description(self, event):
        try:
            idx = self.task_list.curselection()[0]
            task = self.tasks[idx]
            messagebox.showinfo(task.title, f"Description: {task.description}\nCategory: {task.category}")
        except IndexError:
            pass

    def save_and_exit(self):
        save_tasks(self.tasks)
        self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()

    splash = SplashScreen(root)

    def start_app():
        splash.destroy()
        root.deiconify()
        TodoApp(root)

    root.after(3000, start_app)
    root.mainloop()
