# Personal To-Do List (CLI)

A simple, local, command-line To-Do application in Python. No databases, just a JSON file for storage.

## Features
- Add, view (filters), edit, complete, and delete tasks
- Categorize tasks (Work, Personal, Urgent, or custom)
- Persistent storage in `tasks.json`
- Zero external dependencies

## Project Structure
```
todo_app/
├─ todo.py       # Main program
├─ tasks.json    # Data storage (auto-created)
└─ README.md     # Documentation
```

## How to Run
1. Ensure Python 3.8+ is installed.
2. Open a terminal in this folder and run:
   ```bash
   python todo.py
   ```
3. Follow the on-screen menu.

## Usage Tips
- Press Enter on edit prompts to keep existing values.
- Use the View menu to filter by pending or by category.
- Data auto-saves after each action and on exit.

## Future Enhancements (Ideas)
- GUI with Tkinter
- Due dates & priority levels
- Search and sorting
- Export/Import CSV

## License
Free to use for learning and personal projects.
